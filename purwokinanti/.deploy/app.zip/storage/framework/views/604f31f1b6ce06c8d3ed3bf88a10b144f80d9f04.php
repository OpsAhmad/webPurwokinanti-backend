<?php
use  Illuminate\Support\Facades\Crypt; //helper crypt
?>



<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <!-- ============================================================== -->
    <!-- Container fluid  -->
    <!-- ============================================================== -->
    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <div class="row page-titles">
            <div class="col-md-5 align-self-center">
                <h3 class="text-themecolor">Data keluarga</h3>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0)">Kependudukan</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.kependudukan.keluarga')); ?>">keluarga</a></li>
                    <li class="breadcrumb-item active">Detail keluarga</li>
                </ol>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- End Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Start Page Content -->
        <!-- ============================================================== -->
        <div class="row">
            <!-- column -->
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <h4 class="card-title">Detail Keluarga</h4>
                            <div>
                            <a href="<?php echo e(route('admin.kependudukan.keluarga.destroy',['id' => $keluarga->id])); ?>" class="btn btn-link text-danger">Hapus Keluarga</a>
                                /
                            <a href="<?php echo e(route('admin.kependudukan.add',['keluarga_id'=>$keluarga->id])); ?>" class="btn btn-link">Tambah anggota</a>
                            </div>
                        </div>
                        <h6 class="card-subtitle"> <code></code></h6>
                        <div class="table-responsive mt-4">
                            <h5>Informasi Keluarga :</h5>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>KB</th>
                                        <th>KS</th>
                                        <th>PUS</th>
                                        <th>Kepala keluarga</th>
                                        <th>Edit</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><?php echo e($keluarga->kb); ?></td>
                                        <td><?php echo e($keluarga->ks); ?></td>
                                        <td><?php echo e($keluarga->pus); ?></td>
                                        <td><?php echo e($keluarga->kependudukan->name); ?></td>
                                        <td>
                                        <a href="<?php echo e(route('admin.kependudukan.keluarga.edit',['id' => $keluarga->id])); ?>" class="btn btn-sm btn-primary">Edit</a></td>
                                    </tr>
                                </tbody>
                            </table>
                            <h5>Anggota Keluarga :</h5>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Nama</th>
                                        <th>Status</th>
                                        <th>Tanggal lahir</th>
                                        <th>NIK</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $keluarga->penduduk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                    <td><?php echo e(++$key); ?></td>
                                        <td><?php echo e($pend->name); ?></td>
                                        <td><?php echo e($pend->status); ?></td>
                                        <td><?php echo e(date('d-m-Y', strtotime(Crypt::decryptString($pend->born)))); ?></td>
                                        <td><?php echo e(Crypt::decryptString($pend->nik)); ?></td>
                                        <td>
                                            <a href="<?php echo route('admin.kependudukan.detail',['id'=>$pend->id]); ?>" class="btn btn-sm btn-outline-primary">Detail</a>
                                            <a href="<?php echo route('admin.kependudukan.edit',['id'=>$pend->id]); ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
                                            <a href="<?php if($keluarga->kependudukan_id != $pend->id): ?><?php echo e(route('admin.kependudukan.destroy',['id'=>$pend->id])); ?><?php else: ?> <?php echo e(route('admin.kependudukan.keluarga.destroy',['id' => $keluarga->id])); ?><?php endif; ?>" class="btn btn-sm btn-outline-danger">Delete</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- End PAge Content -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Container fluid  -->
    <!-- ============================================================== -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\github\webPurwokinanti-backend\purwokinanti\resources\views/admin/kependudukan/keluarga-detail.blade.php ENDPATH**/ ?>