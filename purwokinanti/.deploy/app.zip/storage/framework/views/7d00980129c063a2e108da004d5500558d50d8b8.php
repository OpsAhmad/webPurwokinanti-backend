    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="<?php echo e(asset('vendor/admin-wrap')); ?>/node_modules/jquery/jquery.min.js"></script>
    <!-- Bootstrap popper Core JavaScript -->
    <script src="<?php echo e(asset('vendor/admin-wrap')); ?>/node_modules/bootstrap/js/popper.min.js"></script>
    <script src="<?php echo e(asset('vendor/admin-wrap')); ?>/node_modules/bootstrap/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="<?php echo e(asset('vendor/admin-wrap')); ?>/js/perfect-scrollbar.jquery.min.js"></script>
    <!--Wave Effects -->
    <script src="<?php echo e(asset('vendor/admin-wrap')); ?>/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="<?php echo e(asset('vendor/admin-wrap')); ?>/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="<?php echo e(asset('vendor/admin-wrap')); ?>/js/custom.min.js"></script>
    <!-- ============================================================== -->
    <!-- This page plugins -->
    <!-- ============================================================== -->
    <!--morris JavaScript -->
    <script src="<?php echo e(asset('vendor/admin-wrap')); ?>/node_modules/raphael/raphael-min.js"></script>
    <script src="<?php echo e(asset('vendor/admin-wrap')); ?>/node_modules/morrisjs/morris.min.js"></script>
    <!--c3 JavaScript -->
    <script src="<?php echo e(asset('vendor/admin-wrap')); ?>/node_modules/d3/d3.min.js"></script>
    <script src="<?php echo e(asset('vendor/admin-wrap')); ?>/node_modules/c3-master/c3.min.js"></script>
    <!-- Chart JS -->
    <script src="<?php echo e(asset('vendor/admin-wrap')); ?>/js/dashboard1.js"></script><?php /**PATH F:\github\webPurwokinanti-backend\purwokinanti\resources\views/admin/layouts/script.blade.php ENDPATH**/ ?>