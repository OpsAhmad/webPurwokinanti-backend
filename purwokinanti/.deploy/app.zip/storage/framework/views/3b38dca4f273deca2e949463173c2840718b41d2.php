<nav class="nav" id="navbar">
    <div class="container-nav">
      <a href="/" class="menu-link"><div class="logo">Purwokinanti</div></a>
      <ul class="menu nav-small-hide" id="menu">
        <a href="<?php echo e(route('berita')); ?>" class="menu-link <?php if(request()->is('berita')): ?> active <?php endif; ?>"><li>Berita</li></a>
        <a href="<?php echo e(route('agenda')); ?>" class="menu-link <?php if(request()->is('agenda')): ?> active <?php endif; ?>"><li>Agenda</li></a>
        <a href="<?php echo e(route('kependudukan')); ?>" class="menu-link <?php if(request()->is('kependudukan')): ?> active <?php endif; ?>"><li>Kependudukan</li></a>
        <a href="<?php echo e(route('kb')); ?>" class="menu-link <?php if(request()->is('kb')): ?> active <?php endif; ?>"><li>KB</li></a>
        <a href="<?php echo e(route('ks')); ?>" class="menu-link <?php if(request()->is('ks')): ?> active <?php endif; ?>"><li>KS</li></a>
        <a href="<?php echo e(route('pus')); ?>" class="menu-link <?php if(request()->is('pus')): ?> active <?php endif; ?>"><li>PUS</li></a>
      </ul>
      <div class="hamburger" onclick="navbar_responsive()">
        <div id="h-one"></div>
        <div id="h-two"></div>
        <div id="h-three"></div>
      </div>
    </div>
  </nav><?php /**PATH F:\github\webPurwokinanti-backend\purwokinanti\resources\views/public/layouts/navbar.blade.php ENDPATH**/ ?>