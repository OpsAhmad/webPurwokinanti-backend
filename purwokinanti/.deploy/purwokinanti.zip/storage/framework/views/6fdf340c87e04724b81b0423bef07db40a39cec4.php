

<?php $__env->startSection('content'); ?>
    
<style>
  .jumbotron{
background: url("<?php echo e(Storage::url($jumbotron->image)); ?>");
background-repeat: no-repeat;
background-position: center;
background-size: cover;
  }
</style>
<div class="jumbotron">
<div class="wrapper">
  <div class="container">
  <h1><?php echo e($jumbotron->title); ?></h1>
    <p>
    <?php echo e($jumbotron->description); ?>

    </p>
  </div>
</div>
</div>

<!-- Contents -->
<div class="container">
<!-- Section tentang -->
<div class="mt-5"></div>
<div style="position: relative">
  <div
    class="target"
    style="position: absolute; top: -150px"
    id="section-tentang"
  ></div>
  <div class="section-title">Tentang</div>
  <div class="line" style="width: 130px"></div>
  <div class="row">
    <div class="col-lg-6">
      <p>
      <?php echo e($about[0]); ?>

      </p>
    </div>
    <div class="col-lg-6">
      <?php echo e($about[1]); ?>

    </div>
  </div>
</div>
<!-- Section berita -->
<div class="mt-5"></div>
<div id="section-news">
  <div class="section-title">Berita Terbaru</div>
  <div class="line" style="width: 130px"></div>
  <div class="row">
  <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4 mb-3">
      <div class="card border-0">
        <div class="card-img">
          <img src="<?php echo e(Storage::url('public/News')); ?>/<?php echo e($b->thumbnail); ?>" alt="<?php echo e($b->thumbnail); ?>" class="w-100" />
        </div>
        <div class="card-body">
          <h5 class="card-title"><?php echo e($b->title); ?></h5>
          <p class="card-text"><?php echo e($b->created_at->diffForHumans()); ?></p>
        </div>
      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
<!-- Section agenda -->
<div class="mt-5"></div>
<div id="section-agenda">
    <div class="section-title">Agenda Terbaru</div>
    <div class="line" style="width: 130px"></div>
    <div class="row">
      <?php $__currentLoopData = $agenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-4 mb-3">
      <div class="card">
        <div class="card-body">
          <h5 class="card-title"><?php echo e($a->title); ?></h5>
          <p class="card-text"><?php echo e($a->date->formatLocalized('%A, %d %B %Y')); ?></p>
          <a href="#" class="btn btn-sm btn-outline-primary">Detail</a>
        </div>
      </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
<!-- Section agenda -->
<div class="mt-5"></div>
<div id="section-kepengurusan">
  <div class="section-title">Kepengurusan</div>
  <div class="line" style="width: 130px"></div>
  <div class="row">
  <?php $__currentLoopData = $kepengurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-3 col-6">
      <div class="card-profile bg-light mb-3">
      <img src="<?php echo e(Storage::url($k->avatar)); ?>" alt="<?php echo e($k->avatar); ?>" />
        <div class="nama mt-2"><?php echo e($k->name); ?></div>
        <div class="jabatan"><?php echo e($k->position); ?></div>
      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
<div class="mb-5"></div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\github\webPurwokinanti-backend\purwokinanti\resources\views/public/index.blade.php ENDPATH**/ ?>