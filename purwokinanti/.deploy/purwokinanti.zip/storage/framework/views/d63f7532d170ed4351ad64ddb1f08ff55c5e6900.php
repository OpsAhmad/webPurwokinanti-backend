

<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <!-- ============================================================== -->
    <!-- Container fluid  -->
    <!-- ============================================================== -->
    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <div class="row page-titles">
            <div class="col-md-5 align-self-center">
                <h3 class="text-themecolor">Tambah Kepengurusan</h3>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0)">Kepengurusan</a></li>
                    <li class="breadcrumb-item active">Tambah Kepengurusan</li>
                </ol>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- End Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Start Page Content -->
        <!-- ============================================================== -->
        <div class="row">
            <!-- column -->
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Tambah kepengurusan</h4>
                        <h6 class="card-subtitle"> <code></code></h6>
                           <div class="row mt-5">
                               <div class="col-md-8">
                               <form class="form" method="post" action="<?php echo e(route('admin.kepengurusan.insert')); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="custom-file">
                                        <input class="custom-file-input" type="file" id="input-file" name="avatar" onchange="labelImage()" required>
                                        <label for="my-input" class="custom-file-label" id="label-file">Foto profil</label>
                                    </div>
                                    <div class="form-group mt-2">
                                        <label for="my-input">Nama</label>
                                    <input id="my-input" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="name" value="<?php echo e(old('name')); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="my-input">Jabatan</label>
                                        <input id="my-input" class="form-control <?php $__errorArgs = ['position'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="position" value="<?php echo e(old('position')); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="my-select">Prioritas</label>
                                        <select id="my-select" class="form-control <?php $__errorArgs = ['priority'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="priority">
                                            <option disabled selected>Pilih</option>
                                            <option>1</option>
                                            <option>2</option>
                                            <option>3</option>
                                            <option>4</option>
                                            <option>5</option>
                                            <option>5</option>
                                            <option>6</option>
                                            <option>6</option>
                                            <option>9</option>
                                            <option>10</option>
                                        </select>
                                    </div>
                                    <button type="submit" class="btn btn-primary float-right">Tambah pengurus</button>
                                </form>
                               </div>
                           </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- End PAge Content -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Container fluid  -->
    <!-- ============================================================== -->
</div>
<script>
    function labelImage()
    {
        inputFile = document.getElementById('input-file');
        labelFile = document.getElementById('label-file');

        labelFile.innerHTML = inputFile.files[0].name;
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\github\webPurwokinanti-backend\purwokinanti\resources\views/admin/kepengurusan/add.blade.php ENDPATH**/ ?>