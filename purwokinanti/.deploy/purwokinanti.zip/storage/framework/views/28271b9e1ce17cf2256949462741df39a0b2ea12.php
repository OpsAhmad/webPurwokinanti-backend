

<?php $__env->startSection('content'); ?>
    <!-- ============================================================== -->
    <!-- Container fluid  -->
    <!-- ============================================================== -->
   <div class="container-fluid bg-light d-flex justify-content-center align-items-center" style="height: 100vh;">
        <div class="box bg-white p-5">
            <h1>Login</h1>
        <form action="<?php echo e(route('admin.login.verify')); ?>" method="POST" class="form mt-4">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="my-input">Username</label>
            <input id="my-input" class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="username">
        </div>
        <div class="form-group">
            <label for="my-input">Password</label>
            <input id="my-input" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="password" name="password">
        </div>
        <button type="submit" class="btn btn-primary float-right">Login</button>
        </form>
        </div>
   </div>
    <!-- ============================================================== -->
    <!-- End Container fluid  -->
    <!-- ============================================================== -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\github\webPurwokinanti-backend\purwokinanti\resources\views/admin/login.blade.php ENDPATH**/ ?>