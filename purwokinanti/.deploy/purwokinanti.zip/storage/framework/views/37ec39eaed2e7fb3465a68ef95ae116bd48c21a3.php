

<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <!-- ============================================================== -->
    <!-- Container fluid  -->
    <!-- ============================================================== -->
    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <div class="row page-titles">
            <div class="col-md-5 align-self-center">
                <h3 class="text-themecolor"><?php echo e($judul_halaman ?? 'Edit Halaman'); ?></h3>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:void(0)">Edit Halaman</a></li>
                    <li class="breadcrumb-item active"><?php echo e($judul_halaman ?? 'Edit Halaman'); ?></li>
                </ol>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- End Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Start Page Content -->
        <!-- ============================================================== -->
        <div class="row">
            <!-- column -->
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title"><?php echo e($judul_halaman ?? 'Edit Halaman'); ?></h4>
                        <h6 class="card-subtitle"> <code></code></h6>
                           <div class="row mt-5">
                               <div class="col-md-8">
                               <form class="form" method="post" action="<?php echo e(route('admin.halaman.update')); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('patch'); ?>
                                    
                                    <input type="hidden" name="_location" value="<?php echo e($data->location); ?>">
                                    
                                    <?php if(isset($data->image)): ?>
                                    <input type="hidden" name="_old_image" value="<?php echo e($data->image); ?>">
                                    <div class="custom-file">
                                        <input class="custom-file-input" type="file" id="input-file" name="image" onchange="labelImage()">
                                        <label for="my-input" class="custom-file-label" id="label-file"><?php echo e(Str::limit($data->image,30,'...')); ?></label>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <?php if(isset($data->title)): ?>
                                    <div class="form-group mt-2">
                                        <label for="my-input">Judul</label>
                                    <input id="my-input" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="title" value="<?php echo e($data->title); ?>">
                                    </div>
                                    <?php endif; ?>
                                    
                                    <?php if(isset($data->description)): ?>
                                    <div class="form-group">
                                        <label for="my-input">Deskripsi</label>
                                        <textarea id="my-input" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="6" name="description" ><?php echo e($data->description); ?></textarea>
                                    </div>
                                    <?php endif; ?>
                                    <div class="mt-3"></div>
                                    <button type="submit" class="btn btn-primary float-right">Simpan data</button>
                                </form>
                               </div>
                           </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- End PAge Content -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Container fluid  -->
    <!-- ============================================================== -->
</div>
<script>
    function labelImage()
    {
        inputFile = document.getElementById('input-file');
        labelFile = document.getElementById('label-file');

        labelFile.innerHTML = inputFile.files[0].name;
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\github\webPurwokinanti-backend\purwokinanti\resources\views/admin/pages/index.blade.php ENDPATH**/ ?>