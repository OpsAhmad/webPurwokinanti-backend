<?php 
use Illuminate\Support\Carbon;
?>



<?php $__env->startSection('content'); ?>
    
<style>
  .jumbotron{
background: url("<?php echo e(Storage::url($jumbotron->image)); ?>");
background-repeat: no-repeat;
background-position: center;
background-size: cover;
  }
</style>
<div class="jumbotron" id="page">
<div class="wrapper">
  <div class="container">
  <h1><?php echo e($jumbotron->title); ?></h1>
    <p>
    <?php echo e($jumbotron->description); ?>

    </p>
  </div>
</div>
</div>

<div class="container">

<?php if(isset($berita)): ?>
<!-- SECTION BERITA START -->
<div class="mt-5"></div>
<div id="section-news">
  <div class="section-title">Berita</div>
  <div class="line" style="width: 130px"></div>
  <div class="row">
  <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4 mb-3">
      <a href="<?php echo e(route('berita.single',['slug' => $b->slug])); ?>" class="text-decoration-none text-dark text-bold">
        <div class="card border-0">
          <div class="card-img">
            <img src="<?php echo e(Storage::url('public/News')); ?>/<?php echo e($b->thumbnail); ?>" alt="<?php echo e($b->thumbnail); ?>" class="w-100" />
          </div>
          <div class="card-body">
            <h5 class="card-title"><?php echo e($b->title); ?></h5>
            <p class="card-text"><?php echo e($b->created_at->diffForHumans()); ?></p>
          </div>
        </div>
      </a>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
    <div class="d-flex justify-content-center mb-5">
      <?php echo e($berita->links('vendor.pagination.bootstrap-4')); ?>

    </div>
</div>

<?php endif; ?>

<?php if(isset($agenda)): ?>
<!-- SECTION AGENDA START -->
<div class="mt-5"></div>
<div id="section-agenda">
    <div class="section-title">Agenda</div>
    <div class="line" style="width: 130px"></div>
    <div class="row">
      <?php $__currentLoopData = $agenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-4 mb-3">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title"><?php echo e($a->title); ?></h5>
                <p class="card-text"><?php echo e($a->date->formatLocalized('%A, %d %B %Y')); ?></p>
                <a href="<?php echo e(route('agenda.single',['slug' => $a->slug])); ?>" class="btn btn-sm btn-outline-primary">Detail</a>
              </div>
            </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <div class="d-flex justify-content-center mb-5">
    <?php echo e($agenda->links('vendor.pagination.bootstrap-4')); ?>

  </div>
</div>
<!-- SECTION AGENDA END -->
<?php endif; ?>

<?php if(isset($kependudukan)): ?>
<!-- SECTION KEPENDUDUKAN START -->
<div class="mt-5"></div>
<div id="section-kependudukan">
  <div class="d-flex justify-content-between align-items-center">
    <div class="section-title">Kependudukan</div>
    <form action="" class="form d-flex align-items-center">
        <input type="text" name="q" class="form-control mr-3 w-75" placeholder="Cari Nama Penduduk">
        <button type="submit" class="btn btn-sm btn-primary">Cari</button>
    </form>
    </div>
    <div class="line" style="width: 130px"></div>
    <div class="table-responsive">
      <table class="table table-light">
        <tbody>
          <tr>
            <td>No.</td>
            <td>Nama</td>
            <td>Usia</td>
            <td>Jenis Kelamin</td>
            <td>Pekerjaan</td>
          </tr>
        </tbody>
        <?php $__empty_1 = true; $__currentLoopData = $kependudukan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td><?php echo e($kependudukan->firstItem() + $key); ?></td>
          <td><?php echo e($p->name); ?></td>
          <td><?php echo e(Carbon::parse(date('d-m-Y', strtotime(Crypt::decryptString($p->born))))->age); ?></td>
          <td><?php echo e($p->gender); ?></td>
          <td><?php echo e($p->job); ?></td>
        </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td>Data kosong</td>
        </tr>
        <?php endif; ?>
      </table>
    </div>
  <div class="d-flex justify-content-center mb-5 mt-3">
    <?php echo e($kependudukan->appends(request()->except('page'))->links('vendor.pagination.bootstrap-4')); ?>

  </div>
</div>
<!-- SECTION KEPENDUDUKAN END -->
<?php endif; ?>

<?php if(isset($kb)): ?>
<!-- SECTION KB START -->
<div class="mt-5"></div>
<div id="section-kependudukan">
  <div class="d-flex justify-content-between align-items-center">
    <div class="section-title">Keluarga Berencana</div>
    <form action="" class="form d-flex align-items-center">
        <input type="text" name="q" class="form-control mr-3 w-75" placeholder="Cari Nama Keluarga">
        <button type="submit" class="btn btn-sm btn-primary">Cari</button>
    </form>
    </div>
    <div class="line" style="width: 130px"></div>
    <div class="table-responsive">
      <table class="table table-light">
        <tbody>
          <tr>
            <td>No.</td>
            <td>Kepala keluarga</td>
            <td></td>
          </tr>
        </tbody>
        <?php $__empty_1 = true; $__currentLoopData = $kb; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td><?php echo e($kb->firstItem() + $key); ?></td>
          <td><?php echo e($k->name); ?></td>
          <td>
          <a href="<?php echo e(route('keluarga.detail',['id' => $k->id,'from' => 'kb'])); ?>" class="btn btn-sm btn-outline-primary">Detail</a>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td>Data kosong</td>
        </tr>
        <?php endif; ?>
      </table>
    </div>
  <div class="d-flex justify-content-center mb-5 mt-3">
    <?php echo e($kb->appends(request()->except('page'))->links('vendor.pagination.bootstrap-4')); ?>

  </div>
</div>
<!-- SECTION KB END -->
<?php endif; ?>

<?php if(isset($ks)): ?>
<!-- SECTION KS START -->
<div class="mt-5"></div>
<div id="section-kependudukan">
  <div class="d-flex justify-content-between align-items-center">
    <div class="section-title">Keluarga Sejahtera</div>
    <form action="" class="form d-flex align-items-center">
        <input type="text" name="q" class="form-control mr-3 w-75" placeholder="Cari Nama Keluarga">
        <button type="submit" class="btn btn-sm btn-primary">Cari</button>
    </form>
    </div>
    <div class="line" style="width: 130px"></div>
    <div class="table-responsive">
      <table class="table table-light">
        <tbody>
          <tr>
            <td>No.</td>
            <td>Kepala keluarga</td>
            <td></td>
          </tr>
        </tbody>
        <?php $__empty_1 = true; $__currentLoopData = $ks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td><?php echo e($ks->firstItem() + $key); ?></td>
          <td><?php echo e($k->name); ?></td>
          <td>
          <a href="<?php echo e(route('keluarga.detail',['id' => $k->id,'from' => 'ks'])); ?>" class="btn btn-sm btn-outline-primary">Detail</a>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td>Data kosong</td>
        </tr>
        <?php endif; ?>
      </table>
    </div>
  <div class="d-flex justify-content-center mb-5 mt-3">
    <?php echo e($ks->appends(request()->except('page'))->links('vendor.pagination.bootstrap-4')); ?>

  </div>
</div>
<!-- SECTION KS END -->
<?php endif; ?>

<?php if(isset($pus)): ?>
<!-- SECTION PUS START -->
<div class="mt-5"></div>
<div id="section-kependudukan">
  <div class="d-flex justify-content-between align-items-center">
    <div class="section-title">PUS</div>
    <form action="" class="form d-flex align-items-center">
        <input type="text" name="q" class="form-control mr-3 w-75" placeholder="Cari Nama Keluarga">
        <button type="submit" class="btn btn-sm btn-primary">Cari</button>
    </form>
    </div>
    <div class="line" style="width: 170px"></div>
    <div class="table-responsive">
      <table class="table table-light">
        <tbody>
          <tr>
            <td>No.</td>
            <td>Kepala keluarga</td>
            <td></td>
          </tr>
        </tbody>
        <?php $__empty_1 = true; $__currentLoopData = $pus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td><?php echo e($pus->firstItem() + $key); ?></td>
          <td><?php echo e($k->name); ?></td>
          <td>
          <a href="<?php echo e(route('keluarga.detail',['id' => $k->id,'from' => 'pus'])); ?>" class="btn btn-sm btn-outline-primary">Detail</a>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td>Data kosong</td>
        </tr>
        <?php endif; ?>
      </table>
    </div>
  <div class="d-flex justify-content-center mb-5 mt-3">
    <?php echo e($pus->appends(request()->except('page'))->links('vendor.pagination.bootstrap-4')); ?>

  </div>
</div>
<!-- SECTION PUS END -->
<?php endif; ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\github\webPurwokinanti-backend\purwokinanti\resources\views/public/page.blade.php ENDPATH**/ ?>