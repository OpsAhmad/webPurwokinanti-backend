

<?php $__env->startSection('content'); ?>
    
<style>
  .jumbotron{
background: url("<?php echo e(Storage::url($jumbotron->image)); ?>");
background-repeat: no-repeat;
background-position: center;
background-size: cover;
  }
</style>
<div class="jumbotron" id="page">
<div class="wrapper">
  <div class="container">
  <h1><?php echo e($jumbotron->title); ?></h1>
    <p>
    <?php echo e($jumbotron->description); ?>

    </p>
  </div>
</div>
</div>

<div class="container">

<?php if(isset($berita)): ?>
<!-- SECTION BERITA START -->
<div class="mt-5"></div>
<div id="section-news">
  <div class="section-title">Berita</div>
  <div class="line" style="width: 130px"></div>
  <div class="row mb-5">
    
    <div class="col-lg-6">
    <img src="<?php echo e(Storage::url('public/News')."/".$berita->thumbnail); ?>" alt="<?php echo e($berita->thumbnail); ?>" class="w-100">
    <h1 class="my-2"><?php echo e($berita->title); ?></h1>
    <div class="my-2"><?php echo e($berita->created_at->formatLocalized('%A, %d %B %Y')); ?></div>
    </div>
    
    <div class="col-lg-6">
        <?php echo nl2br($berita->body); ?>

    </div>
  </div>

</div>

<?php endif; ?>

<?php if(isset($agenda)): ?>
<!-- SECTION AGENDA START -->
<div class="mt-5"></div>
<div id="section-agenda">
    <div class="section-title">Agenda</div>
    <div class="line" style="width: 130px"></div>
    <div class="row mt-3 mb-5">
        <div class="col-lg-6 px-lg-4">
            <div class="border border-secondary p-3 rounded">
                <h1 class="mt-4"><?php echo e($agenda->title); ?></h1>
                <p><?php echo nl2br($agenda->description); ?></p>
            </div>
        </div>    
        <div class="col-lg-6 px-lg-4 my-lg-0 my-3">
            <div class="border border-secondary p-3 rounded">
                <p class="text text-bold">Lokasi: <?php echo e($agenda->location); ?></p>
                <p>Tanggal: <?php echo e($agenda->date->formatLocalized('%A, %d %B %Y')); ?></p>
                <p>Waktu: <?php echo e($agenda->time); ?></p>
            </div>
        </div>    
    </div>
    </div>
  </div>
</div>
<!-- SECTION AGENDA END -->
<?php endif; ?>

<?php if(isset($keluarga)): ?>
<!-- SECTION KELUARGA START -->
<div class="mt-5"></div>
<div id="section-agenda">
    <div class="section-title">Detail Keluarga</div>
    <div class="line" style="width: 130px"></div>
    <div class="table-responsive mt-4">
        <h5>Informasi Keluarga :</h5>
        <table class="table">
            <thead class="bg-primary text-white">
                <tr>
                    <th>KB</th>
                    <th>KS</th>
                    <th>PUS</th>
                    <th>Kepala keluarga</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?php echo e($keluarga->kb); ?></td>
                    <td><?php echo e($keluarga->ks); ?></td>
                    <td><?php echo e($keluarga->pus); ?></td>
                    <td><?php echo e($keluarga->kependudukan->name); ?></td>
                </tr>
            </tbody>
        </table>
        <h5>Anggota Keluarga :</h5>
        <table class="table">
            <thead class="bg-secondary text-white">
                <tr>
                    <th>#</th>
                    <th>Nama</th>
                    <th>Status</th>
                    <th>Usia</th>
                    <th>Jenis Kelamin</th>
                    <th>Pekerjaan</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $keluarga->penduduk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e(++$key); ?></td>
                    <td><?php echo e($pend->name); ?></td>
                    <td><?php echo e($pend->status); ?></td>
                     <td><?php echo e($carbon->parse(date('d-m-Y', strtotime(Crypt::decryptString($pend->born))))->age); ?></td>
                    <td><?php echo e($pend->gender); ?></td>
                    <td><?php echo e($pend->job); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
            <div class="my-5">
        <a href="<?php echo e($back); ?>" class="btn btn-sm btn-outline-secondary">Kembali</a>
    </div>
    </div>
  </div>
</div>
<!-- SECTION KELUARGA END -->
<?php endif; ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\github\webPurwokinanti-backend\purwokinanti\resources\views/public/single.blade.php ENDPATH**/ ?>