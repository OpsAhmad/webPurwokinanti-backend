

<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <!-- ============================================================== -->
    <!-- Container fluid  -->
    <!-- ============================================================== -->
    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <div class="row page-titles">
            <div class="col-md-5 align-self-center">
                <h3 class="text-themecolor">Detail kependudukan</h3>
                <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.kependudukan.penduduk')); ?>">Kependudukan</a></li>
                    <li class="breadcrumb-item active">Detail</li>
                    <li class="breadcrumb-item active">Edit</li>
                </ol>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- End Bread crumb and right sidebar toggle -->
        <!-- ==========================================1==================== -->
        <!-- ============================================================== -->
        <!-- Start Page Content -->
        <!-- ============================================================== -->
        <div class="row">
            <!-- column -->
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Detail keluarga</h4>
                        <h6 class="card-subtitle"><code></code></h6>
                        <form method="post" action="<?php echo e(route('admin.kependudukan.update')); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('patch'); ?>
                        <input type="hidden" name="_id" value="<?php echo e($penduduk->id); ?>">
                        <div class="row">
                            <div class="col-lg-8">
                                <div class="form-group">
                                    <label for="my-input">Nama</label>
                                    <input id="my-input" class="form-control  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="name" placeholder="" value="<?php echo e($penduduk->name); ?>">
                                </div>        
                                <div class="form-group">
                                    <label for="my-input">Tanggal Lahir</label>
                                    <input id="my-input" class="form-control <?php $__errorArgs = ['born'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="date" name="born"  value="<?php echo e(Crypt::decryptString($penduduk->born)); ?>">
                                </div>        
                                <div class="form-group">
                                    <label for="my-input">NIK</label>
                                    <input id="my-input" class="form-control <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="number" name="nik"  value="<?php echo e(Crypt::decryptString($penduduk->nik)); ?>">
                                </div>        
                                <div class="form-group">
                                    <label for="my-input">Alamat</label>
                                    <input id="my-input" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="address"  value="<?php echo e($penduduk->address); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="my-input">Jenis Kelamin</label>
                                    <select name="gender" id="" class="form-control <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <option disabled selected>Pilih</option>
                                        <option value="Laki-Laki" <?php if($penduduk->gender == "Laki-Laki"): ?> selected <?php endif; ?>>Laki-Laki</option>
                                        <option value="Perempuan" <?php if($penduduk->gender == "Perempuan"): ?> selected <?php endif; ?>>Perempuan</option>
                                    </select>
                                </div>         
                             <div class="row">
                                 <div class="col-md-4">
                                <div class="form-group">
                                    <label for="my-input">Status hubungan</label>
                                    <select name="status" id="" class="form-control <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <option <?php if($penduduk->status == "Suami"): ?> selected <?php endif; ?>>Suami</option>
                                        <option <?php if($penduduk->status == "Istri"): ?> selected <?php endif; ?>>Istri</option>
                                        <option <?php if($penduduk->status == "Anak"): ?> selected <?php endif; ?>>Anak</option>
                                        <option <?php if($penduduk->status == "Famili lain"): ?> selected <?php endif; ?>>Famili lain</option>
                                    </select>
                                </div>        
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="my-input">Pekerjaan</label>
                                    <select name="job" id="" class="form-control <?php $__errorArgs = ['job'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <option <?php if($penduduk->job == "Tidak bekerja"): ?> selected <?php endif; ?>>Tidak bekerja</option>
                                        <option <?php if($penduduk->job == "Rumah Tangga"): ?> selected <?php endif; ?>">Rumah Tangga</option>
                                        <option <?php if($penduduk->job == "Mahasiswa"): ?> selected <?php endif; ?>">Pelajar/Mahasiswa</option>
                                        <option <?php if($penduduk->job == "PNS/ASN"): ?> selected <?php endif; ?>>PNS/ASN</option>
                                        <option <?php if($penduduk->job == "Wirausaha"): ?> selected <?php endif; ?>>Wirausaha</option>
                                        <option <?php if($penduduk->job == "Karyawan Swasta"): ?> selected <?php endif; ?>>Karyawan Swasta</option>
                                        <option <?php if($penduduk->job == "Buruh"): ?> selected <?php endif; ?>>Buruh</option>
                                        <option <?php if($penduduk->job == "Guru/Dosen"): ?> selected <?php endif; ?>>Guru/Dosen</option>
                                        <option <?php if($penduduk->job == "Lainya"): ?> selected <?php endif; ?>>Lainya</option>
                                    </select>
                                </div>  
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="my-input">Pendidikan</label>
                                    <select name="education" id="" class="form-control <?php $__errorArgs = ['education'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <option value="Tidak sekolah">Tidak sekolah</option>
                                        <option <?php if($penduduk->education == "SD"): ?> selected <?php endif; ?>>SD</option>
                                        <option <?php if($penduduk->education == "SMP"): ?> selected <?php endif; ?>>SMP</option>
                                        <option <?php if($penduduk->education == "SMA"): ?> selected <?php endif; ?>>SMA</option>
                                        <option <?php if($penduduk->education == "D1"): ?> selected <?php endif; ?>>D1</option>
                                        <option <?php if($penduduk->education == "D2"): ?> selected <?php endif; ?>>D2</option>
                                        <option <?php if($penduduk->education == "D3"): ?> selected <?php endif; ?>>D3</option>
                                        <option <?php if($penduduk->education == "D4"): ?> selected <?php endif; ?>">D4</option>
                                        <option <?php if($penduduk->education == "S1"): ?> selected <?php endif; ?>>S1</option>
                                        <option <?php if($penduduk->education == "S2"): ?> selected <?php endif; ?>>S2</option>
                                        <option <?php if($penduduk->education == "S3"): ?> selected <?php endif; ?>>S3</option>
                                        <option <?php if($penduduk->education == "Lainya"): ?> selected <?php endif; ?>>Lainya</option>
                                    </select>
                                </div>    
                            </div>          
                            <div class="d-flex justify-content-between align-items-center w-100">
                                <a href="<?php if($from == ''): ?> <?php echo e(route('admin.kependudukan.keluarga.detail',['id' => $penduduk->keluarga_id])); ?> <?php else: ?>
                                 <?php echo e(route('admin.kependudukan.penduduk')); ?> <?php endif; ?>" class="btn btn-secondary">Kembali</a>
                                <button  type="submit" class="btn btn-primary">Simpan perubahan</a>
                            </div>
                        </form>
                            </div>          
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- End PAge Content -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Container fluid  -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\github\webPurwokinanti-backend\purwokinanti\resources\views/admin/kependudukan/edit.blade.php ENDPATH**/ ?>